-- Migration: add favorites + soft delete support to contacts
-- Run this ONCE if you already created the schema before these columns existed.

ALTER TABLE contacts
    ADD COLUMN is_favorite TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN deleted_at TIMESTAMP NULL;

CREATE INDEX idx_contacts_is_favorite ON contacts(is_favorite);
CREATE INDEX idx_contacts_deleted_at ON contacts(deleted_at);
