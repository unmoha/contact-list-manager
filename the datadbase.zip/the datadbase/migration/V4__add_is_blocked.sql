-- Add is_blocked column to contacts table
ALTER TABLE contacts ADD COLUMN is_blocked BOOLEAN DEFAULT FALSE;
