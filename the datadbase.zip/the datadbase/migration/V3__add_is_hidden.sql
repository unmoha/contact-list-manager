-- Add is_hidden column to contacts table
ALTER TABLE contacts ADD COLUMN is_hidden BOOLEAN DEFAULT FALSE;

-- Verify the column was added
DESCRIBE contacts;
