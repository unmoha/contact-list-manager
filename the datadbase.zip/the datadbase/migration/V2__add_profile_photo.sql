-- Add profile_photo column to contacts table
ALTER TABLE contacts ADD COLUMN profile_photo VARCHAR(500);
