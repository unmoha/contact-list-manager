-- Sample data for quick testing

INSERT INTO contact_groups (name) VALUES
('Family'),
('Friends'),
('Work')
ON DUPLICATE KEY UPDATE name = name;

INSERT INTO contacts (first_name, last_name, phone, email, address, notes, group_id, is_emergency, is_favorite)
SELECT 'Aisha', 'Hassan', '+966500000001', 'aisha.hassan@example.com', 'Riyadh', 'VIP contact', g.id, 0, 1
FROM contact_groups g
WHERE g.name='Family'
  AND NOT EXISTS (SELECT 1 FROM contacts c WHERE c.email='aisha.hassan@example.com');

INSERT INTO contacts (first_name, last_name, phone, email, address, notes, group_id, is_emergency, is_favorite)
SELECT 'Omar', 'Saleh', '+966500000002', 'omar.saleh@example.com', 'Jeddah', 'Met at conference', g.id, 0, 0
FROM contact_groups g
WHERE g.name='Work'
  AND NOT EXISTS (SELECT 1 FROM contacts c WHERE c.email='omar.saleh@example.com');

INSERT INTO contacts (first_name, last_name, phone, email, address, notes, group_id, is_emergency, is_favorite)
SELECT 'Lina', 'Adel', '+966500000003', 'lina.adel@example.com', 'Dammam', 'Close friend', g.id, 1, 0
FROM contact_groups g
WHERE g.name='Friends'
  AND NOT EXISTS (SELECT 1 FROM contacts c WHERE c.email='lina.adel@example.com');
