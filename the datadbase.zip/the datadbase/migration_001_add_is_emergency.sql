-- Migration: add emergency flag to contacts table
-- Run this ONCE if you already created the schema before is_emergency existed.

ALTER TABLE contacts
    ADD COLUMN is_emergency TINYINT(1) NOT NULL DEFAULT 0;

CREATE INDEX idx_contacts_is_emergency ON contacts(is_emergency);
