-- Migration 003: Add contact_history table for timeline/history feature
CREATE TABLE IF NOT EXISTS contact_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    contact_id BIGINT NOT NULL,
    action_type VARCHAR(32) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    description TEXT,
    INDEX idx_contact_history_contact_id (contact_id),
    INDEX idx_contact_history_created_at (created_at),
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
);
