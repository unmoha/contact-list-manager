-- MySQL schema for Contact List Manager
-- Run this first:
--   CREATE DATABASE contact_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
--   USE contact_manager;

CREATE TABLE IF NOT EXISTS contact_groups (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_contact_groups_name (name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS contacts (
    id BIGINT NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    phone VARCHAR(40) NULL,
    email VARCHAR(160) NULL,
    address VARCHAR(255) NULL,
    notes TEXT NULL,
    group_id BIGINT NULL,
    is_emergency TINYINT(1) NOT NULL DEFAULT 0,
    is_favorite TINYINT(1) NOT NULL DEFAULT 0,
    deleted_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_contacts_last_name (last_name),
    KEY idx_contacts_first_name (first_name),
    KEY idx_contacts_phone (phone),
    KEY idx_contacts_email (email),
    KEY idx_contacts_group_id (group_id),
    KEY idx_contacts_is_emergency (is_emergency),
    KEY idx_contacts_is_favorite (is_favorite),
    KEY idx_contacts_deleted_at (deleted_at),
    CONSTRAINT fk_contacts_group_id
        FOREIGN KEY (group_id) REFERENCES contact_groups(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;
