-- Profile Photo Migration
-- Run this SQL to add profile_photo column to contacts table

ALTER TABLE contacts ADD COLUMN profile_photo VARCHAR(500);

-- Verify the column was added
DESCRIBE contacts;
