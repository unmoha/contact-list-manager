# Contact List Manager (Java 25 + JavaFX 25 + MySQL)

## Prerequisites
- Java 25
- Maven 3.9+
- MySQL 8+

## Database setup
1. Create DB:
   - `CREATE DATABASE contact_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;`
2. Run schema:
   - Execute `src/main/resources/db/schema.sql`
3. If you created the schema before the emergency feature was added:
   - Execute `src/main/resources/db/migration_001_add_is_emergency.sql`
4. If you created the schema before favorites/soft-delete were added:
   - Execute `src/main/resources/db/migration_002_add_favorite_and_soft_delete.sql`
3. (Optional) Insert sample data:
   - Execute `src/main/resources/db/sample_data.sql`

## Configure DB credentials
Edit `src/main/resources/application.properties`:
- `db.url`
- `db.username`
- `db.password`

## Run
- `mvn javafx:run`

## Import / Export
- Export is available via the File menu.
- Import CSV is available via the File menu.

## Calling features
- **Call** opens Telegram Desktop using a `tg://` deep link for the selected contact's phone.
- **Emergency Call** asks for confirmation, then:
  - If the selected contact is marked as emergency, it uses that contact's phone.
  - Otherwise, it lets you pick a predefined emergency number.

Notes:
- Telegram Desktop must be installed and must have registered the `tg://` protocol for deep links.
- If Telegram deep-link fails, Emergency Call falls back to opening a `tel:` URI using your system defaults.
