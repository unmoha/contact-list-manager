-- Manual SQL script to add is_hidden column to contacts table
-- Run this script manually against your H2 database

ALTER TABLE contacts ADD COLUMN is_hidden BOOLEAN DEFAULT FALSE;

-- Verify the column was added
SELECT COLUMN_NAME, TYPE_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'CONTACTS';
